﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class clsFormaEvidencijaObukeSpisak
    {
        // atributi
        private string pStringKonekcije;

        // property

        // konstruktor
        public clsFormaEvidencijaObukeSpisak(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaGrid(string filter)
        {
            DataSet dsPodaci = new DataSet();
            clsEvidencijaObukeDB objEvidencijaObukeDB = new clsEvidencijaObukeDB(pStringKonekcije);
            if (filter.Equals(""))
            {
                dsPodaci = objEvidencijaObukeDB.DajSveEvidencijeObuke(); 
            }
            else
            {
                dsPodaci = objEvidencijaObukeDB.DajEvidencijuObukePoTipuObuke(filter);
            }
            return dsPodaci;
        }

    }
}
