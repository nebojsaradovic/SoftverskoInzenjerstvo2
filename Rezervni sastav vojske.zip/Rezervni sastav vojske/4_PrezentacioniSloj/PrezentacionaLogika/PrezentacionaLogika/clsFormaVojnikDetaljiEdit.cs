﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class clsFormaVojnikDetaljiEdit
    {
   // atributi i property
        private string pStringKonekcije;
        private clsVojnikDB objVojnikDB;

        private clsVojnik objPreuzetiVojnik;
        private clsVojnik objIzmenjeniVojnik;

        private int pJMBGPreuzetogVojnika;
        private string pPrezimePreuzetogVojnika;
        private string pImePreuzetogVojnika;
        private string pPolPreuzetogVojnika;
        private DateTime pDatumRodjenjaPreuzetogVojnika;

        private int pJMBGIzmenjenogVojnika;
        private string pPrezimeIzmenjenogVojnika;
        private string pImeIzmenjenogVojnika;
        private string pPolIzmenjenogVojnika;
        private DateTime pDatumRodjenjaIzmenjenogVojnika;

        // PROPERTY

        public int JMBGPreuzetogVojnika
        {
            get { return pJMBGPreuzetogVojnika; }
            set { pJMBGPreuzetogVojnika = value; pPrezimePreuzetogVojnika = DajPrezime(pJMBGPreuzetogVojnika); }
        }

        public string PrezimePreuzetogVojnika
        {
            get { return pPrezimePreuzetogVojnika; }
        }
        public string ImePreuzetogVojnika
        {
            get { return pImePreuzetogVojnika; }
        }
        public string PolPreuzetogVojnika
        {
            get { return pPolPreuzetogVojnika; }
        }
        public DateTime DatumRodjenjaPreuzetogVojnika
        {
            get { return pDatumRodjenjaPreuzetogVojnika; }
        }

        public int JMBGIzmenjenogVojnika
        {
            get { return pJMBGIzmenjenogVojnika; }
            set { pJMBGIzmenjenogVojnika = value; }
        }


        public string PrezimeIzmenjenogVojnika
        {
            get { return pPrezimeIzmenjenogVojnika; }
            set { pPrezimeIzmenjenogVojnika = value; }
        }
        public string ImeIzmenjenogVojnika
        {
            get { return pImeIzmenjenogVojnika; }
            set { pImeIzmenjenogVojnika = value; }
        }
        public string PolIzmenjenogVojnika
        {
            get { return pPolIzmenjenogVojnika; }
            set { pPolIzmenjenogVojnika = value; }
        }
        public DateTime DatumRodjenjaIzmenjenogVojnika
        {
            get { return pDatumRodjenjaIzmenjenogVojnika; }
            set { pDatumRodjenjaIzmenjenogVojnika = value; }
        }


        // konstruktor
        public clsFormaVojnikDetaljiEdit(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
            objVojnikDB = new clsVojnikDB(pStringKonekcije);
        }

        // privatne metode
        private string DajPrezime(int pomJMBG)
        {
            string pomPrezime ="";
            DataSet dsPodaci = new DataSet();
            pomPrezime = objVojnikDB.DajPrezimePremaJMBGVojnika(pomJMBG); 

            return pomPrezime;
        }

        // javne metode
        public bool ObrisiVojnika()
        {
            // zvanje koje je trenutno u atributima dato, TJ. preuzeta sifra je bitna
            bool uspehBrisanja = false;
            uspehBrisanja = objVojnikDB.ObrisiVojnika(JMBGPreuzetogVojnika);  

            return uspehBrisanja;

        }

        public bool IzmeniVojnika()
        {
            bool uspehIzmene = false;
            objPreuzetiVojnik = new clsVojnik();
            objIzmenjeniVojnik = new clsVojnik();

            objPreuzetiVojnik.JMBG = pJMBGPreuzetogVojnika ;
            objPreuzetiVojnik.Prezime = pPrezimePreuzetogVojnika;
            objPreuzetiVojnik.Ime = pImePreuzetogVojnika;
            objPreuzetiVojnik.Pol = pPolPreuzetogVojnika;
            objPreuzetiVojnik.DatumRodjenja = pDatumRodjenjaPreuzetogVojnika;

            objIzmenjeniVojnik.JMBG = pJMBGIzmenjenogVojnika;
            objIzmenjeniVojnik.Prezime = pPrezimeIzmenjenogVojnika;
            objIzmenjeniVojnik.Ime = pImeIzmenjenogVojnika;
            objIzmenjeniVojnik.Pol = pPolIzmenjenogVojnika;
            objIzmenjeniVojnik.DatumRodjenja = pDatumRodjenjaIzmenjenogVojnika;

            uspehIzmene = objVojnikDB.IzmeniVojnika(objPreuzetiVojnik, objIzmenjeniVojnik);  

            return uspehIzmene;
        }
    }
}
