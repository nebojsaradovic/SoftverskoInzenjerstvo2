﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class clsFormaVojnikTabelaEdit
    {
        // atributi
        private string pStringKonekcije;

        // property

        // konstruktor
        public clsFormaVojnikTabelaEdit(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaGrid(string filter)
        {
            DataSet dsPodaci = new DataSet();
            clsVojnikDB objVojnikDB = new clsVojnikDB(pStringKonekcije);            
            if (filter.Equals(""))
            {
                dsPodaci = objVojnikDB.DajSveVojnike(); 
            }
            else
            {
                dsPodaci = objVojnikDB.DajVojnikaPoPrezimenu(filter); 
            }
            return dsPodaci;
        }
    }
}
