﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;
using PoslovnaLogika;

namespace PrezentacionaLogika
{
    public class clsFormaEvidencijaObukeUnos
    {
        // atributi
        private string pStringKonekcije;
        private int pId;
        private string pNaziv;
        private string pTipObuke;
        private string pMestoObuke;
        private string pPrezimeVojnika;

        // property
        public int Id
        {
            get { return pId; }
            set { pId = value; }
        }
        
        public string Naziv
        {
            get { return pNaziv; }
            set { pNaziv = value; }
        }
        
        public string TipObuke
        {
            get { return pTipObuke; }
            set { pTipObuke = value; }
        }
   
        public string MestoObuke
        {
            get { return pMestoObuke; }
            set { pMestoObuke = value; }
        }

        public string PrezimeVojnika
        {
            get { return pPrezimeVojnika; }
            set { pPrezimeVojnika = value; }
        }
        
        // konstruktor
        public clsFormaEvidencijaObukeUnos(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaCombo()
        {
            DataSet dsPodaci = new DataSet();
            clsVojnikDB objVojnikDB = new clsVojnikDB(pStringKonekcije);

            dsPodaci = objVojnikDB.DajSveVojnike() ; 
            
            return dsPodaci;
        }

        public bool DaLiJeSvePopunjeno()
        {
            bool SvePopunjeno = false;

            // PITANJE U NEGATIVNOM KONTEKSTU if ((txbJMBG.Text.Length == 0) || (txbPrezime.Text.Length == 0) || (txbIme.Text.Length == 0) || (ddlZvanje.Text.Length == 0) || (ddlZvanje.Text == "Izaberite..."))

            // PRERADA KODA - IF (da li nesto jeste)

            if ((pId > 0) && (pNaziv.Length > 0) && (pTipObuke.Length > 0)  && (pMestoObuke.Length > 0) && (pPrezimeVojnika.Length > 0) && (!pPrezimeVojnika.Equals("Izaberite...")))
            {
                SvePopunjeno = true;
            }
            else
            {
                SvePopunjeno = false;
            }

            return SvePopunjeno;
        }


        public bool DaLiJeJedinstvenZapis()
        {
            bool JedinstvenZapis = false;
            DataSet dsPodaci = new DataSet();
            clsEvidencijaObukeDB objEvidencijaObukeDB = new clsEvidencijaObukeDB(pStringKonekcije);
            dsPodaci = objEvidencijaObukeDB.DajEvidencijuObukePoId(pId);
            
            if (dsPodaci.Tables[0].Rows.Count == 0)
            {
                JedinstvenZapis = true;
            }
            else
            {
                JedinstvenZapis = false;
            }

            return JedinstvenZapis;

        }

        public bool SnimiPodatke()
        {
            bool uspehSnimanja=false;

            clsEvidencijaObukeDB objEvidencijaObukeDB = new clsEvidencijaObukeDB(pStringKonekcije);

            clsEvidencijaObuke objNovaEvidencijaOBuke = new clsEvidencijaObuke();
            objNovaEvidencijaOBuke.Id = pId;
            objNovaEvidencijaOBuke.Naziv = pNaziv;
            objNovaEvidencijaOBuke.TipObuke = pTipObuke;
            objNovaEvidencijaOBuke.MestoObuke = pMestoObuke;

            clsVojnik objVojnik = new clsVojnik();

            clsVojnikDB objVojnikDB = new clsVojnikDB(pStringKonekcije);
            objVojnik.JMBG= objVojnikDB.DajJMBGVojnikaPoPrezimenu(pPrezimeVojnika);
            objVojnik.Prezime = pPrezimeVojnika;

            objNovaEvidencijaOBuke.Vojnik  = objVojnik; 
            
            uspehSnimanja = objEvidencijaObukeDB.SnimiNovuEvidencijuObuke(objNovaEvidencijaOBuke); 


            return uspehSnimanja;
        }

        public bool DaLiSuPodaciUskladjeniSaPoslovnimPravilima()
        {
            // POSLOVNO PRAVILO:
            // Na fakultetu ne moze biti zaposleno vise nastavnika u odredjenom
            // zvanju nego sto je dozvoljeno maksimalnim brojem prema Sistematizaciji
            // radnih mesta.
            bool UskladjeniPodaci = false;

            clsPoslovnaPravila objPoslovnaPravila = new clsPoslovnaPravila(pStringKonekcije);
            
            //izracunavanje ID zvanja
            clsVojnikDB objVojnikDB = new clsVojnikDB(pStringKonekcije);
            int JMBGVojnika = objVojnikDB.DajJMBGVojnikaPoPrezimenu(pPrezimeVojnika); 
                       
            UskladjeniPodaci = objPoslovnaPravila.DaLiJeVojnikPohadjaoDovoljanBrojCasovaKakoBiObukaBilaFinalizirana(JMBGVojnika);

            return UskladjeniPodaci;
        }
    }
}
